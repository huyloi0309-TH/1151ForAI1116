/* Exercise: evaluate a postfix expression with a stack.
 * Build: gcc -std=c11 -Wall -Wextra -pedantic -o exercise starter.c && ./exercise */
#include <ctype.h>
#include <stdio.h>

#define MAX 50

/* Evaluates single digits and + - * / separated by spaces, for example "2 3 +".
 * Returns 0 and stores the value in *result, or returns -1 on any error
 * (stack underflow, division by zero, bad character, leftover values). */
int eval_postfix(const char *expr, int *result) {
//@SOL
    int stack[MAX];
    int top = -1;
    for (size_t i = 0; expr[i] != '\0'; i++) {
        char c = expr[i];
        if (c == ' ') continue;
        if (isdigit((unsigned char)c)) {
            if (top == MAX - 1) return -1;
            stack[++top] = c - '0';
        } else if (c == '+' || c == '-' || c == '*' || c == '/') {
            if (top < 1) return -1;
            int b = stack[top--];
            int a = stack[top--];
            if (c == '/' && b == 0) return -1;
            int r = (c == '+') ? a + b : (c == '-') ? a - b : (c == '*') ? a * b : a / b;
            stack[++top] = r;
        } else {
            return -1;
        }
    }
    if (top != 0) return -1;
    *result = stack[top];
    return 0;
//@TODO
    /* TODO: push digits; on an operator pop b then a, push (a op b); report every error with -1 */
    (void)expr; (void)result;
    return -1;
//@END
}

static int failures = 0;
static void expect_value(const char *expr, int value) {
    int r = 0;
    int ok = eval_postfix(expr, &r) == 0 && r == value;
    printf("%s: \"%s\" -> %d\n", ok ? "PASS" : "FAIL", expr, value);
    if (!ok) failures++;
}
static void expect_error(const char *expr) {
    int r = 0;
    int ok = eval_postfix(expr, &r) == -1;
    printf("%s: \"%s\" -> error\n", ok ? "PASS" : "FAIL", expr);
    if (!ok) failures++;
}

int main(void) {
    expect_value("2 3 +", 5);
    expect_value("5 1 2 + 4 * + 3 -", 14);
    expect_value("8 2 /", 4);
    expect_error("4 0 /");
    expect_error("+");
    expect_error("1 2");
    expect_error("2 x +");
    if (failures) printf("%d test(s) failed\n", failures);
    else printf("All tests passed\n");
    return failures != 0;
}
