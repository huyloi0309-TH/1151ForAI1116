#!/bin/sh
# Run from the project root: sh tools/check.sh
# Compiles every C file with strict flags, runs lesson programs against expected output,
# checks that exercise solutions pass and starters compile, then validates JS and data.
set -e
FLAGS="-std=c11 -Wall -Wextra -pedantic -Werror"
for f in assets/code/*/*.c; do
  gcc $FLAGS -o /tmp/dsh_prog "$f"
  [ -f "${f%.c}.out" ] && /tmp/dsh_prog | diff -u "${f%.c}.out" -
done
for d in assets/exercises/*/; do
  gcc $FLAGS -o /tmp/dsh_sol "${d}solution.c"
  /tmp/dsh_sol | grep -q FAIL && { echo "Solution fails its own tests: $d"; exit 1; }
  gcc $FLAGS -o /tmp/dsh_start "${d}starter.c"
done
for f in $(find assets tools -name '*.js' -o -name '*.mjs'); do
  node --check "$f" 2>/dev/null || node --input-type=module --check < "$f" >/dev/null
done
node tools/check-data.mjs
echo "All checks passed"
