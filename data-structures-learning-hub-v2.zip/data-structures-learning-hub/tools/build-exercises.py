#!/usr/bin/env python3
"""Builds starter.c and solution.c for every file in tools/exercise-src/.
Marker lines: //@SOL starts solution code, //@TODO starts starter code, //@END ends both."""
import pathlib

root = pathlib.Path(__file__).resolve().parent.parent
for src in sorted((root / 'tools' / 'exercise-src').glob('*.c')):
    out = root / 'assets' / 'exercises' / src.stem
    out.mkdir(parents=True, exist_ok=True)
    solution, starter, mode = [], [], 'both'
    for line in src.read_text().splitlines():
        tag = line.strip()
        if tag == '//@SOL': mode = 'sol'
        elif tag == '//@TODO': mode = 'todo'
        elif tag == '//@END': mode = 'both'
        else:
            if mode in ('both', 'sol'): solution.append(line)
            if mode in ('both', 'todo'): starter.append(line)
    (out / 'solution.c').write_text('\n'.join(solution) + '\n')
    (out / 'starter.c').write_text('\n'.join(starter) + '\n')
    print('built', src.stem)
