// Validates the registry, lesson content, and exercise files. Run from the project root.
import { lessons } from '../assets/data/lessons.js';
import { exercises } from '../assets/data/exercises.js';
import { existsSync } from 'node:fs';

const errors = [];
const slugs = new Set(lessons.map(l => l.slug));
const blockTypes = new Set(['p', 'ul', 'table', 'pre', 'diagram', 'sim', 'play', 'code', 'exercises', 'quiz']);
for (const l of lessons) {
  for (const p of l.prerequisites) if (!slugs.has(p)) errors.push(`${l.slug}: unknown prerequisite ${p}`);
  if (l.status !== 'done') continue;
  if (!existsSync(`lessons/${l.slug}.html`)) errors.push(`${l.slug}: missing lessons/${l.slug}.html`);
  const c = (await import(`../assets/data/content/${l.slug}.js`)).default;
  if (c.sections.length !== 15) errors.push(`${l.slug}: needs 15 sections, has ${c.sections.length}`);
  c.sections.forEach(s => s.body.forEach(b => {
    if (!blockTypes.has(b[0])) errors.push(`${l.slug}: unknown block type ${b[0]}`);
    if (b[0] === 'code') for (const f of [b[1]]) if (!existsSync(`assets/code/${l.slug}/${f}`)) errors.push(`${l.slug}: missing code file ${f}`);
  }));
  if (c.quiz.length < 6) errors.push(`${l.slug}: quiz needs at least 6 questions`);
  c.quiz.forEach((q, i) => { if (!q.options[q.answer]) errors.push(`${l.slug}: quiz question ${i + 1} has a bad answer index`); });
  c.related.forEach(s => { if (!slugs.has(s)) errors.push(`${l.slug}: unknown related lesson ${s}`); });
  if (!exercises.some(e => e.lesson === l.slug)) errors.push(`${l.slug}: no exercises`);
}
for (const e of exercises) {
  if (!slugs.has(e.lesson)) errors.push(`${e.id}: unknown lesson ${e.lesson}`);
  e.concepts.forEach(s => { if (!slugs.has(s)) errors.push(`${e.id}: unknown concept ${s}`); });
  for (const f of ['starter.c', 'solution.c']) if (!existsSync(`assets/exercises/${e.id}/${f}`)) errors.push(`${e.id}: missing ${f}`);
}
console.log(errors.length ? errors.join('\n') : 'Data checks passed');
process.exit(errors.length ? 1 : 0);
