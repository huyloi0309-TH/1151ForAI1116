# Data Structures Learning Hub

A learning site for data structures taught in **C11**: visual simulations, complete C programs, exercises, and quizzes.

- Live site: add your GitHub Pages link here
- Rules for AI agents: [AGENTS.md](AGENTS.md)
- Curriculum and status: `assets/data/lessons.js`

## Run locally

ES modules need a server. In this folder run `python -m http.server 8000`, then open http://localhost:8000 (or use the VS Code Live Server extension).

## Check the project

`sh tools/check.sh` compiles every C file with `-std=c11 -Wall -Wextra -pedantic -Werror`, runs them against expected output, and validates the data. It needs GCC and Node.js.

## Add a lesson

Ask your AI agent: "Add the Queue lesson." It follows section 9 of AGENTS.md. Stack is the reference lesson.

## Deploy

GitHub repository, Settings, Pages, Deploy from a branch, `main` / `(root)`. Develop on a separate branch (for example `upgrade`) and merge when ready.
