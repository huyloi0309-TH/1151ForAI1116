# AGENTS.md — Data Structures Learning Hub

This file tells AI coding agents how this project works. Read it fully before changing anything.

## 1. Project Overview

**Data Structures Learning Hub** is an educational website that helps beginners understand data structures through visual explanations, interactive demonstrations, real-world examples, and exercises.

- **Audience:** beginners with little or no prior knowledge of data structures.
- **Language:** simple English for both the website and the documentation.
- **Learning flow:** Learn → Observe → Practice → Test → Review.

### Goals

- Make complex concepts easy to understand.
- Explain *how* and *why* each data structure works.
- Visualize how data is stored, organized, and changed by operations.
- Connect theory with real-world applications.
- Keep the architecture expandable so new topics can be added quickly.

## 2. Technology Rules

| Allowed | Not allowed |
|---|---|
| HTML, CSS, vanilla JavaScript (ES modules) | React, Vue, or any framework |
| GitHub, GitHub Pages | Backend, database, build tools |
| Local files in this repository | CDN links, npm packages, external fonts |

- **C11 is the implementation language for every data structure and exercise.** No C++ (no iostream, cin, cout, vector, STL, classes, templates). JavaScript is only for website features and visual simulations.
- No paid APIs. The site must work as a static site on GitHub Pages with no build step.
- The site shows C code but does not run or grade it. Never claim code is executed or graded unless it really is.
- Use **relative paths only** (for example `../assets/css/base.css`). Never start a path with `/`, because GitHub Pages serves the site from a sub-path.
- ES modules need a local server to test. Run `python -m http.server 8000` in the project root and open `http://localhost:8000`.

## 3. Site Structure

| Area | Path | Purpose |
|---|---|---|
| Home | `index.html` | Introduction, goals, and learning roadmap |
| Learning Modules | `modules/index.html` | List of module groups and their lessons |
| Lessons | `lessons/<topic>.html` | One page per data structure or algorithm |
| Interactive Playground | `playground/index.html` | Free experimenting with structures |
| Practice & Quiz | `practice/index.html` | Exercises and knowledge checks |
| Glossary | `glossary/index.html` | English terms for data structures and algorithms |

Every page shares the same header navigation: Home, Modules, Playground, Practice, Glossary.

## 4. Folder Structure

```
data-structures-learning-hub/
├── AGENTS.md, CLAUDE.md (only: @AGENTS.md), README.md, package.json
├── index.html
├── modules/index.html            curriculum, filter by level
├── lessons/<slug>.html           tiny stub per lesson (the renderer builds the page)
├── practice/index.html, practice/exercise.html   exercise list and viewer (?id=)
├── playground/, glossary/, guide/run-c-locally.html
├── assets/css/                   base, layout, components, lesson
├── assets/js/
│   ├── structures/               pure logic, no DOM
│   ├── visuals/                  drawing only
│   ├── lesson/                   renderer.js, sims.js (one entry per structure)
│   ├── pages/                    per-page scripts
│   └── shared/                   nav, dom, quiz, progress, code-block, step-player
├── assets/data/
│   ├── lessons.js                registry: single source of truth for curriculum and status
│   ├── content/<slug>.js         15-section lesson content (copy _template.js)
│   ├── quizzes/<slug>-quiz.js
│   └── exercises.js, glossary.js
├── assets/code/<slug>/           lesson C programs (*.c) and expected output (*.out)
├── assets/exercises/<id>/        starter.c and solution.c (generated, do not edit by hand)
└── tools/                        check.sh, check-data.mjs, build-exercises.py, exercise-src/
```

### Naming rules

- Lowercase English with hyphens for files and folders. One slug per topic everywhere (`binary-search-tree`).
- JavaScript: `camelCase` functions, `PascalCase` classes. CSS classes: lowercase with hyphens.
- C: `snake_case` functions prefixed by the structure (`stack_push`), `PascalCase` types.

## 5. Learning Scope

The curriculum (tracks, levels, types, prerequisites, status) lives in `assets/data/lessons.js`. That file is the single source of truth: do not duplicate the list here. A lesson is `done` only when it passes section 11. Currently done: Stack (the reference lesson). Lessons are built phase by phase: Foundations, Linear, Hash, Trees, Graphs, Advanced, Algorithms.

Data structures and algorithms are different things. A data structure organizes data and offers operations. An algorithm is a procedure that uses structures to solve a problem. Mark each lesson as `concept`, `ds`, or `algo` in the registry, and make algorithm lessons say which structures they use.

## 6. Lesson Structure (15 sections)

Lessons are data-driven. Never hand-write lesson HTML. A lesson is `assets/data/content/<slug>.js` plus a stub `lessons/<slug>.html` (copy `lessons/_template.html`). Every data-structure lesson has these 15 sections, in this order (`tools/check-data.mjs` enforces the count):

1. Concept and Definition
2. Why It Exists
3. Real-life Analogy
4. How It Works Internally (memory layout)
5. Visual Illustration
6. Step-by-step Simulation
7. Main Operations
8. Real-world Applications
9. Complexity Analysis
10. Advantages and Disadvantages
11. Comparison
12. C Code Examples
13. Code Explanation (functions, pointers, memory changes, dry-run table)
14. Programming Exercises
15. Knowledge Assessment (at least 6 questions)

Depth rules: no one-line definitions as teaching. Explain applications instead of only naming them. Give simple numeric examples and one everyday analogy. Use `Stack` (`assets/data/content/stack.js`) as the reference.

## 6b. C Code Standard

- C11, standard library only, GCC-compatible. Build with `gcc -std=c11 -Wall -Wextra -pedantic -Werror`. Zero warnings.
- Every major lesson ships a complete program in `assets/code/<slug>/` with a header comment (purpose, build, run), `main()`, comments, sample output in a matching `.out` file, and tests: a normal case, boundary cases (empty, full, single item), and error cases.
- Each operation is its own function. Functions report failure with a status code. Check every `malloc` and free everything.
- Forbidden: `gets`, `void main`, `system()`, undefined behavior, variable-length arrays, C++ syntax.

## 6c. Exercise Standard

Three levels: 1 Basic implementation, 2 Application, 3 Problem solving. Each exercise in `assets/data/exercises.js` has: description, objective, required concepts, input and output, examples, tests, three progressive hints, explanation, and complexity. Write the C source once in `tools/exercise-src/<id>.c` with `//@SOL`, `//@TODO`, `//@END` markers, then run `python3 tools/build-exercises.py` to generate `starter.c` and `solution.c`. The solution is hidden behind a confirmation button.

## 7. Design Rules

- Priority: visual learning, simplicity, clarity, easy navigation.
- Define all colors, spacing, and font sizes as CSS variables in `base.css`. Do not hard-code colors in other files.
- Layout is centered, with content width up to 960px, and must work on mobile screens.
- Use system fonts, body text 16px, line height 1.6.
- Use color and shape consistently in visuals: the same color for the "active/top" element, another for "highlighted", another for "error".
- Each animation must have Play/Next/Reset controls, or step buttons, so learners can follow at their own pace.
- Text must have enough contrast; interactive elements must be reachable with the keyboard and have visible focus.
- Do not use inline `style` attributes or inline `onclick` handlers.

## 8. Code Rules

- **Separate logic from display.** Files in `structures/` implement the data structure only and never touch the DOM. Files in `visuals/` draw the state. Files in `pages/` connect buttons to both.
- Data structure operations must be **correct** first: check empty and full cases, return clear results, and never silently fail.
- Visuals must match the real behavior. Example: a stack only changes at the top; a queue adds at the rear and removes from the front. Never draw something that breaks the rule of the structure.
- Keep files short and functions small. Add a short comment above each non-obvious function.
- Do not duplicate code between topics. Put shared behavior in `assets/js/shared/`.
- Quiz and glossary content lives in `assets/data/`, not inside HTML.

## 9. Workflow: Adding a New Lesson

1. Read this file and the registry `assets/data/lessons.js`.
2. Explain the plan first (files to create, what the lesson will teach) and wait for approval on larger topics.
3. Write the C program in `assets/code/<slug>/` plus its `.out`. Compile it with the strict flags and run it.
4. Write the JavaScript logic in `structures/` and a drawing function in `visuals/`. Add an entry to `assets/js/lesson/sims.js` (render, build, play).
5. Copy `assets/data/content/_template.js` to `<slug>.js` and write all 15 sections. Add `quizzes/<slug>-quiz.js` (6 or more questions).
6. Copy `lessons/_template.html` to `lessons/<slug>.html`.
7. Add exercises (see 6c) and run `python3 tools/build-exercises.py`.
8. Set the lesson status to `done` in `lessons.js`. Add new terms to `glossary.js`.
9. Run `sh tools/check.sh` and fix every problem.
10. Report which files were created or changed, and say what was NOT verified in a browser.

## 10. AI Behavior Rules

1. Do not change the project goal or scope without being asked.
2. Do not build the whole website in one step. Work in small parts.
3. Explain what a feature does before implementing it.
4. Prefer readable, maintainable code over clever code.
5. Do not create visuals that contradict how the data structure really works.
6. Test each feature after building it.
7. Do not delete or overwrite existing content before checking what it affects.
8. For a major architecture change, explain the reason and wait for approval.
9. Use simple English in documentation and on the website.
10. Do not copy text from textbooks or other websites. Write original explanations.
11. If a request is unclear or conflicts with this file, ask instead of guessing.
12. Do not add libraries, frameworks, or external links that were not approved.

## 11. Done Checklist

- [ ] All 15 sections written; `check-data.mjs` passes.
- [ ] C program compiles with zero warnings, output matches the `.out` file, and covers normal, boundary, and error cases.
- [ ] JavaScript simulation behaves the same as the C program (same capacity and results).
- [ ] Exercises exist for levels 1, 2, and 3; each solution passes its own tests and each starter compiles.
- [ ] Registry status updated; prerequisites and related lessons exist.
- [ ] No broken links, absolute paths, inline styles, or console errors.
- [ ] Opened in a browser: simulation, free play, quiz, copy button, and mobile layout work.
- [ ] Summary of changed files given to the user.

## 12. Git and Deployment

- Hosting: GitHub Pages, branch `main`, root folder.
- Commit messages are short and in English, for example `Add stack lesson` or `Fix queue animation`.
- Make one commit per finished feature.
- Never commit secrets, API keys, or personal data.
