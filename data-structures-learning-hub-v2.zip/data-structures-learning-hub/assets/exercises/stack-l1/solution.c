/* Exercise: implement stack_push and stack_pop.
 * Build: gcc -std=c11 -Wall -Wextra -pedantic -o exercise starter.c && ./exercise */
#include <stdio.h>

#define CAPACITY 5

typedef struct { int data[CAPACITY]; int top; } Stack;

void stack_init(Stack *s) { s->top = -1; }

/* Adds value on top. Returns 0 on success, -1 if the stack is full. */
int stack_push(Stack *s, int value) {
    if (s->top == CAPACITY - 1) return -1;
    s->data[++s->top] = value;
    return 0;
}

/* Removes the top item into *out. Returns 0 on success, -1 if the stack is empty. */
int stack_pop(Stack *s, int *out) {
    if (s->top == -1) return -1;
    *out = s->data[s->top--];
    return 0;
}

static int failures = 0;
static void check(const char *name, int ok) {
    printf("%s: %s\n", ok ? "PASS" : "FAIL", name);
    if (!ok) failures++;
}

int main(void) {
    Stack s;
    int v = 0;
    stack_init(&s);
    check("normal: push 1 and 2", stack_push(&s, 1) == 0 && stack_push(&s, 2) == 0);
    check("normal: pop gives 2 then 1", stack_pop(&s, &v) == 0 && v == 2 && stack_pop(&s, &v) == 0 && v == 1);
    check("error: pop on empty stack returns -1", stack_pop(&s, &v) == -1);
    for (int i = 0; i < CAPACITY; i++) stack_push(&s, i);
    check("boundary: push on full stack returns -1", stack_push(&s, 99) == -1);
    if (failures) printf("%d test(s) failed\n", failures);
    else printf("All tests passed\n");
    return failures != 0;
}
