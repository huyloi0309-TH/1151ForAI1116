/* Exercise: balanced brackets using a stack.
 * Build: gcc -std=c11 -Wall -Wextra -pedantic -o exercise starter.c && ./exercise */
#include <stdio.h>

#define MAX 100

/* Returns 1 if every ( [ { is closed by the matching ) ] } in the right order, else 0.
 * Other characters are ignored. */
int is_balanced(const char *s) {
    char stack[MAX];
    int top = -1;
    for (size_t i = 0; s[i] != '\0'; i++) {
        char c = s[i];
        if (c == '(' || c == '[' || c == '{') {
            if (top == MAX - 1) return 0;
            stack[++top] = c;
        } else if (c == ')' || c == ']' || c == '}') {
            if (top == -1) return 0;
            char open = stack[top--];
            if ((c == ')' && open != '(') || (c == ']' && open != '[') || (c == '}' && open != '{')) return 0;
        }
    }
    return top == -1;
}

static int failures = 0;
static void check(const char *text, int expected) {
    int ok = is_balanced(text) == expected;
    printf("%s: \"%s\" -> %d\n", ok ? "PASS" : "FAIL", text, expected);
    if (!ok) failures++;
}

int main(void) {
    check("([]{})", 1);
    check("a(b)c", 1);
    check("", 1);
    check("(]", 0);
    check("((", 0);
    check("]", 0);
    if (failures) printf("%d test(s) failed\n", failures);
    else printf("All tests passed\n");
    return failures != 0;
}
