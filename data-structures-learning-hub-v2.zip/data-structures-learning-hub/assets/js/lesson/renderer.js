// Builds a lesson page from assets/data/content/<slug>.js (15 sections, in order).
import { lessons } from '../../data/lessons.js';
import { exercises } from '../../data/exercises.js';
import { sims } from './sims.js';
import { renderQuiz } from '../shared/quiz.js';
import { codeBlock } from '../shared/code-block.js';
import { stepPlayer } from '../shared/step-player.js';
import { el } from '../shared/dom.js';

const root = document.body.dataset.root;
const slug = document.body.dataset.lesson;
const meta = lessons.find(l => l.slug === slug);
const levels = { B: 'Beginner', I: 'Intermediate', A: 'Advanced' };
const types = { concept: 'Concept', ds: 'Data Structure', algo: 'Algorithm' };

// Link to a lesson if it exists, plain text if it is still planned.
function lessonRef(s) {
  const l = lessons.find(x => x.slug === s);
  if (l.status !== 'done') return el('span', `${l.title} (coming soon)`);
  const a = el('a', l.title);
  a.href = `${s}.html`;
  return a;
}

// Block types a section body can use. See assets/data/content/_template.js.
const blocks = {
  p: ([, text]) => el('p', text),
  ul: ([, items]) => { const u = el('ul'); items.forEach(i => u.append(el('li', i))); return u; },
  table: ([, rows]) => {
    const wrap = el('div', '', 'table-wrap');
    const t = el('table', '', 'complexity');
    rows.forEach((r, i) => { const tr = el('tr'); r.forEach(c => tr.append(el(i ? 'td' : 'th', c))); t.append(tr); });
    wrap.append(t);
    return wrap;
  },
  pre: ([, text]) => el('pre', text, 'diagram'),
  diagram: ([, items]) => { const box = el('div', '', 'visual-box'); const v = el('div'); sims[slug].render(v, items); box.append(v); return box; },
  sim: ([, ops]) => stepPlayer(sims[slug].build(ops), sims[slug].render),
  play: () => { const d = el('div'); sims[slug].play(d); return d; },
  code: ([, file]) => codeBlock(`${root}assets/code/${slug}/${file}`, file),
  exercises: () => {
    const ul = el('ul');
    exercises.filter(e => e.lesson === slug).forEach(e => {
      const li = el('li');
      const a = el('a', `Level ${e.level}: ${e.title}`);
      a.href = `${root}practice/exercise.html?id=${e.id}`;
      li.append(a);
      ul.append(li);
    });
    return ul;
  },
  quiz: (_, content) => { const d = el('div'); renderQuiz(d, content.quiz, 'quiz:' + slug); return d; }
};

const content = (await import(`../../data/content/${slug}.js`)).default;
document.title = `${meta.title} | Data Structures Learning Hub`;

const article = el('article');
article.append(el('h1', meta.title));
const badges = el('div', '', 'badges');
[types[meta.type], levels[meta.level], meta.track, `About ${content.minutes} min`].forEach(t => badges.append(el('span', t)));
article.append(badges);
if (meta.prerequisites.length) {
  const p = el('p', 'Recommended first: ');
  meta.prerequisites.forEach((s, i) => { if (i) p.append(', '); p.append(lessonRef(s)); });
  article.append(p);
}

const side = el('nav', '', 'sidebar');
side.setAttribute('aria-label', 'Lesson sections');
content.sections.forEach((s, i) => {
  const section = el('section', '', 'lesson-section');
  section.id = `s${i + 1}`;
  section.append(el('h2', `${i + 1}. ${s.title}`));
  s.body.forEach(b => section.append(blocks[b[0]](b, content)));
  article.append(section);
  const a = el('a', `${i + 1}. ${s.title}`);
  a.href = `#s${i + 1}`;
  side.append(a);
});

const related = el('section', '', 'lesson-section');
const list = el('ul');
content.related.forEach(s => { const li = el('li'); li.append(lessonRef(s)); list.append(li); });
related.append(el('h2', 'Related topics'), list);
article.append(related);

const layout = el('div', '', 'lesson-layout');
layout.append(side, article);
document.getElementById('lesson').append(layout);
