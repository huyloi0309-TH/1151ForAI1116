// One entry per structure: how to draw it, build a step trace, and run free play.
import { Stack } from '../structures/stack.js';
import { renderStack } from '../visuals/stack-view.js';
import { el } from '../shared/dom.js';

const CAPACITY = 4; // same capacity as assets/code/stack/stack_array.c

// Runs one operation and returns the caption that explains it.
function run(stack, op, value) {
  if (op === 'push') return stack.push(value) ? `push(${value}): top moves up and ${value} is stored.` : `push(${value}) refused: the stack is full (STACK_FULL).`;
  if (op === 'pop') return stack.isEmpty() ? 'pop() refused: the stack is empty (STACK_EMPTY).' : `pop() returns ${stack.pop()}. top moves down.`;
  if (op === 'peek') return stack.isEmpty() ? 'peek() refused: the stack is empty.' : `peek() returns ${stack.peek()}. Nothing changes.`;
  return `isEmpty() returns ${stack.isEmpty()}.`;
}
const draw = (view, items) => { view.className = 'stack-view'; renderStack(view, { toArray: () => items }); };

export const sims = {
  stack: {
    render: draw,
    build(ops) {
      const s = new Stack(CAPACITY);
      const steps = [{ state: [], caption: 'Empty stack: top = -1.' }];
      for (const [op, value] of ops) steps.push({ caption: run(s, op, value), state: s.toArray() });
      return steps;
    },
    play(host) {
      const s = new Stack(CAPACITY);
      const view = el('div');
      const caption = el('p', 'Type a value and press push.', 'caption');
      caption.setAttribute('aria-live', 'polite');
      const input = el('input');
      input.type = 'text'; input.maxLength = 6;
      input.setAttribute('aria-label', 'Value to push');
      const go = op => {
        const value = input.value.trim();
        if (op === 'push' && !value) { caption.textContent = 'Type a value first.'; return; }
        caption.textContent = run(s, op, value);
        draw(view, s.toArray());
        if (op === 'push') input.value = '';
      };
      const controls = el('div', '', 'controls');
      controls.append(input);
      ['push', 'pop', 'peek', 'isEmpty'].forEach(op => {
        const b = el('button', op, op === 'push' ? 'button' : 'button secondary');
        b.type = 'button';
        b.addEventListener('click', () => go(op));
        controls.append(b);
      });
      const visual = el('div', '', 'visual-box');
      visual.append(view);
      draw(view, []);
      host.append(visual, caption, controls);
    }
  }
};
