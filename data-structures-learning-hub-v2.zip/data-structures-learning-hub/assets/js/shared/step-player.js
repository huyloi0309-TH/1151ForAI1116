// Plays a list of steps: [{ state, caption }]. render(viewElement, state) draws one step.
import { el } from './dom.js';

export function stepPlayer(steps, render) {
  const box = el('div', '', 'player');
  const visual = el('div', '', 'visual-box');
  const view = el('div');
  visual.append(view);
  const caption = el('p', '', 'caption');
  caption.setAttribute('aria-live', 'polite');
  const controls = el('div', '', 'controls');
  let i = 0, timer = null, play = null;

  const show = () => {
    render(view, steps[i].state);
    caption.textContent = `Step ${i} of ${steps.length - 1}. ${steps[i].caption}`;
  };
  const stop = () => { clearInterval(timer); timer = null; play.textContent = 'Play'; };
  const make = (text, cls, fn) => {
    const b = el('button', text, cls);
    b.type = 'button';
    b.addEventListener('click', fn);
    controls.append(b);
    return b;
  };
  make('Previous', 'button secondary', () => { stop(); if (i > 0) { i--; show(); } });
  make('Next', 'button', () => { stop(); if (i < steps.length - 1) { i++; show(); } });
  play = make('Play', 'button secondary', () => {
    if (timer) return stop();
    if (i === steps.length - 1) { i = 0; show(); }
    play.textContent = 'Pause';
    timer = setInterval(() => { if (i < steps.length - 1) { i++; show(); } else stop(); }, 1000);
  });
  make('Reset', 'button secondary', () => { stop(); i = 0; show(); });
  box.append(visual, caption, controls);
  show();
  return box;
}
