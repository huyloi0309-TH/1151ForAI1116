// Tiny helper to create elements safely (text is never parsed as HTML).
export function el(tag, text = '', cls = '') {
  const n = document.createElement(tag);
  if (text) n.textContent = text;
  if (cls) n.className = cls;
  return n;
}
