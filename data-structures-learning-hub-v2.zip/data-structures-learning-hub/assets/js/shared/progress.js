// Progress lives in this browser only (localStorage). Keys: "quiz:<slug>", "ex:<id>".
const KEY = 'dshub-progress-v1';
export function getProgress() {
  try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch { return {}; }
}
export function setProgress(key, value) {
  const data = getProgress();
  data[key] = value;
  try { localStorage.setItem(KEY, JSON.stringify(data)); } catch { /* storage blocked: ignore */ }
}
