// Quiz v2: one answer per question, score at the end, best score saved.
import { el } from './dom.js';
import { getProgress, setProgress } from './progress.js';

export function renderQuiz(root, questions, key) {
  let answered = 0, score = 0;
  const result = el('p', '', 'quiz-result');
  result.setAttribute('aria-live', 'polite');
  const retry = el('button', 'Try again', 'button secondary');
  retry.type = 'button';

  const finish = () => {
    result.textContent = `Your score: ${score}/${questions.length}`;
    retry.hidden = false;
    const best = getProgress()[key];
    if (!best || score > best.score) setProgress(key, { score, total: questions.length });
  };

  const draw = () => {
    root.replaceChildren();
    answered = 0; score = 0; retry.hidden = true; result.textContent = '';
    const best = getProgress()[key];
    if (best) root.append(el('p', `Best score so far: ${best.score}/${best.total}`, 'muted'));
    questions.forEach((item, qi) => {
      const box = el('div', '', 'card quiz-question');
      box.append(el('h3', `${qi + 1}. ${item.question}`));
      const feedback = el('p', '', 'quiz-feedback');
      feedback.setAttribute('aria-live', 'polite');
      const buttons = item.options.map((text, oi) => {
        const b = el('button', text, 'quiz-option');
        b.type = 'button';
        b.addEventListener('click', () => {
          const ok = oi === item.answer;
          if (ok) score++;
          buttons.forEach(x => { x.disabled = true; });
          feedback.textContent = (ok ? 'Correct. ' : 'Not quite. ') + item.explanation;
          feedback.className = 'quiz-feedback ' + (ok ? 'is-correct' : 'is-wrong');
          if (++answered === questions.length) finish();
        });
        return b;
      });
      box.append(...buttons, feedback);
      root.append(box);
    });
    root.append(result, retry);
  };
  retry.addEventListener('click', draw);
  draw();
}
