// Shows a C file with Copy and Download buttons. The site never runs this code.
import { el } from './dom.js';

export function codeBlock(url, name) {
  const box = el('div', '', 'code-block');
  const bar = el('div', '', 'code-bar');
  bar.append(el('strong', name));
  const code = el('code', 'Loading...');
  const pre = el('pre');
  pre.append(code);

  const copy = el('button', 'Copy', 'button secondary');
  copy.type = 'button';
  copy.addEventListener('click', () => {
    navigator.clipboard.writeText(code.textContent).then(
      () => { copy.textContent = 'Copied'; setTimeout(() => { copy.textContent = 'Copy'; }, 1500); },
      () => { copy.textContent = 'Copy failed'; });
  });
  const download = el('a', 'Download', 'button secondary');
  download.href = url;
  download.download = name;
  const tools = el('span');
  tools.append(copy, ' ', download);
  bar.append(tools);

  fetch(url)
    .then(r => { if (!r.ok) throw new Error(r.status); return r.text(); })
    .then(text => { code.textContent = text; })
    .catch(() => { code.textContent = `Could not load ${name}. Open the site through a local server (see README).`; });
  box.append(bar, pre);
  return box;
}
