import { exercises } from '../../data/exercises.js';
import { lessons } from '../../data/lessons.js';
import { codeBlock } from '../shared/code-block.js';
import { getProgress, setProgress } from '../shared/progress.js';
import { el } from '../shared/dom.js';

const root = document.body.dataset.root;
const main = document.getElementById('exercise');
const ex = exercises.find(e => e.id === new URLSearchParams(location.search).get('id'));

if (!ex) {
  main.append(el('h1', 'Exercise not found'), el('p', 'Pick an exercise from the practice list.'));
} else {
  document.title = `${ex.title} | Data Structures Learning Hub`;
  const section = (title, ...nodes) => {
    const s = el('section', '', 'lesson-section');
    s.append(el('h2', title), ...nodes);
    main.append(s);
  };
  main.append(el('h1', ex.title));
  const badges = el('div', '', 'badges');
  [`Level ${ex.level}`, 'Language: C11'].forEach(t => badges.append(el('span', t)));
  main.append(badges);

  section('Problem', el('p', ex.description));
  section('Learning objective', el('p', ex.objective));
  const concepts = el('p');
  ex.concepts.forEach((s, i) => {
    if (i) concepts.append(', ');
    const l = lessons.find(x => x.slug === s);
    if (l.status === 'done') { const a = el('a', l.title); a.href = `${root}lessons/${s}.html`; concepts.append(a); }
    else concepts.append(`${l.title} (coming soon)`);
  });
  section('Required concepts', concepts);
  section('Input and output', el('p', ex.io));
  const examples = el('ul');
  ex.examples.forEach(([a, b]) => examples.append(el('li', `${a}  =>  ${b}`)));
  section('Examples', examples);
  const tests = el('ul');
  ex.tests.forEach(t => tests.append(el('li', t)));
  section('Test cases (built into the starter code)', tests);

  const hints = el('div');
  let shown = 0;
  const hintButton = el('button', 'Show hint 1', 'button secondary');
  hintButton.type = 'button';
  hintButton.addEventListener('click', () => {
    hints.append(el('p', `Hint ${++shown}: ${ex.hints[shown - 1]}`));
    if (shown === ex.hints.length) hintButton.remove(); else hintButton.textContent = `Show hint ${shown + 1}`;
  });
  section('Hints', hints, hintButton);

  section('Starter code',
    el('p', 'Compile and run it on your computer: gcc -std=c11 -Wall -Wextra -pedantic -o exercise starter.c && ./exercise. It prints PASS or FAIL for each built-in test. This site does not run or grade your code.'),
    codeBlock(`${root}assets/exercises/${ex.id}/starter.c`, 'starter.c'));

  const solution = el('div');
  const reveal = el('button', 'I tried it myself. Show the solution', 'button');
  reveal.type = 'button';
  reveal.addEventListener('click', () => {
    reveal.remove();
    solution.append(el('p', ex.explanation), el('p', 'Complexity: ' + ex.complexity),
      codeBlock(`${root}assets/exercises/${ex.id}/solution.c`, 'solution.c'));
  });
  solution.append(reveal);
  section('Reference solution', solution);

  const label = el('label');
  const box = el('input');
  box.type = 'checkbox';
  box.checked = Boolean(getProgress()['ex:' + ex.id]);
  box.addEventListener('change', () => setProgress('ex:' + ex.id, box.checked));
  label.append(box, ' I finished this exercise');
  main.append(label);
}
