import { exercises } from '../../data/exercises.js';
import { getProgress } from '../shared/progress.js';
import { el } from '../shared/dom.js';

const list = document.getElementById('exercise-list');
const progress = getProgress();
const names = { 1: 'Level 1: Basic implementation', 2: 'Level 2: Application', 3: 'Level 3: Problem solving' };
[1, 2, 3].forEach(n => {
  const items = exercises.filter(e => e.level === n);
  if (!items.length) return;
  const section = el('section', '', 'lesson-section');
  const ul = el('ul');
  items.forEach(e => {
    const li = el('li');
    const a = el('a', e.title);
    a.href = `exercise.html?id=${e.id}`;
    li.append(a, progress['ex:' + e.id] ? ' (done)' : '');
    ul.append(li);
  });
  section.append(el('h2', names[n]), ul);
  list.append(section);
});
