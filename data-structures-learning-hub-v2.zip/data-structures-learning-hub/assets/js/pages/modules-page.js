import { lessons } from '../../data/lessons.js';
import { getProgress } from '../shared/progress.js';
import { el } from '../shared/dom.js';

const root = document.getElementById('module-list');
const filter = document.getElementById('level-filter');
const levels = { B: 'Beginner', I: 'Intermediate', A: 'Advanced' };
const types = { concept: 'Concept', ds: 'Data Structure', algo: 'Algorithm' };
const titles = Object.fromEntries(lessons.map(l => [l.slug, l.title]));

function draw() {
  root.replaceChildren();
  const progress = getProgress();
  const groups = new Map();
  lessons.filter(l => !filter.value || l.level === filter.value)
    .forEach(l => groups.set(l.track, [...(groups.get(l.track) || []), l]));
  groups.forEach((items, name) => {
    const section = el('section', '', 'lesson-section');
    const grid = el('div', '', 'grid');
    items.forEach(l => {
      const card = el('div', '', 'card' + (l.status === 'done' ? '' : ' is-planned'));
      const h3 = el('h3');
      if (l.status === 'done') {
        const a = el('a', l.title);
        a.href = `../lessons/${l.slug}.html`;
        h3.append(a);
      } else {
        h3.textContent = `${l.title} (coming soon)`;
      }
      card.append(h3, el('p', `${types[l.type]}, ${levels[l.level]}`, 'badge'));
      if (l.prerequisites.length) card.append(el('p', 'Learn first: ' + l.prerequisites.map(s => titles[s]).join(', '), 'badge'));
      const quiz = progress['quiz:' + l.slug];
      if (quiz) card.append(el('p', `Quiz best score: ${quiz.score}/${quiz.total}`, 'badge'));
      grid.append(card);
    });
    section.append(el('h2', name), grid);
    root.append(section);
  });
}
filter.addEventListener('change', draw);
draw();
