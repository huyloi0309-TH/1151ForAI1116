import { quiz } from '../quizzes/stack-quiz.js';

export default {
  minutes: 45,
  related: ['queue', 'array', 'singly-linked-list', 'recursion', 'dfs'],
  quiz,
  sections: [
    { title: 'Concept and Definition', body: [
      ['p', 'A stack is a collection of items where you can only add or remove at one end, called the top. As an abstract data type (ADT) it offers push (add), pop (remove and return), peek (look without removing), isEmpty, and, for a fixed-size stack, isFull.'],
      ['p', 'Its rule is LIFO: Last In, First Out. The item you added most recently is always the first one to leave.']] },
    { title: 'Why It Exists', body: [
      ['p', 'Many tasks need the newest thing first: undoing the last edit, matching the last opened bracket, returning from the last function call. A plain array lets you change any index, so nothing stops a bug from touching the wrong item.'],
      ['p', 'A stack removes that freedom on purpose. Only the top is reachable, so the order of work is easy to predict, and every operation takes constant time.']] },
    { title: 'Real-life Analogy', body: [
      ['table', [['A pile of plates', 'Stack operation'], ['Put a plate on the pile', 'push'], ['Take the top plate', 'pop'], ['Look at the top plate', 'peek'], ['No plates left', 'isEmpty is true']]],
      ['p', 'Where the analogy breaks: a real pile can be pulled apart from the middle, and a stack forbids that. A real pile also has a physical height limit, which matches a fixed-size array stack but not a linked one.']] },
    { title: 'How It Works Internally', body: [
      ['p', 'The array version keeps items in a C array and one integer, top, holding the index of the newest item. top is -1 when the stack is empty.'],
      ['pre', 'index:   0    1    2    3        capacity = 4\ndata:   10   20   30    -         top = 2\n\npush(40): top becomes 3, then data[3] = 40\npop():    read data[3], then top becomes 2\n          (40 is still in memory, but nothing can reach it)'],
      ['p', 'The linked-list version stores each item in a node with a next pointer, and top points to the newest node. It has no fixed capacity, but every item needs an extra pointer and a separate malloc.']] },
    { title: 'Visual Illustration', body: [
      ['diagram', ['A', 'B', 'C']],
      ['p', 'A was pushed first and sits at the bottom. C was pushed last, sits on top, and will leave first.']] },
    { title: 'Step-by-step Simulation', body: [
      ['p', 'Use Next to watch push and pop change the stack. The capacity is 4, the same as the C program below, so the last push is refused.'],
      ['sim', [['push', '10'], ['push', '20'], ['push', '30'], ['peek'], ['pop'], ['push', '40'], ['push', '50'], ['push', '60'], ['pop'], ['pop']]]] },
    { title: 'Main Operations', body: [
      ['table', [['Operation', 'What it does', 'Edge case'],
        ['push(value)', 'Moves top up, stores value', 'Full stack: overflow, so refuse'],
        ['pop()', 'Returns the top item, moves top down', 'Empty stack: underflow, so refuse'],
        ['peek()', 'Returns the top item, changes nothing', 'Empty stack: nothing to return'],
        ['isEmpty()', 'True when top == -1', 'None'],
        ['isFull()', 'True when top == capacity - 1', 'None (linked version is never full)']]],
      ['p', 'Try them yourself. The capacity is 4.'],
      ['play']] },
    { title: 'Real-world Applications', body: [['ul', [
      'Undo and redo: an editor pushes each change. Undo pops the newest change and pushes it onto a second (redo) stack, so the latest edit is always reverted first.',
      'Balanced brackets: a compiler pushes each opening bracket and pops on each closing one. A mismatch, or a non-empty stack at the end, means the code is unbalanced.',
      'Function calls: each call pushes a frame with its local variables and return address. Returning pops it. Too-deep recursion fills this stack, which is a stack overflow.',
      'Browser back button: visited pages are pushed. Back pops the current page and reveals the previous one.']]] },
    { title: 'Complexity Analysis', body: [
      ['table', [['Operation', 'Time (best, average, worst)', 'Why'],
        ['push', 'O(1)', 'Writes one slot and moves top'],
        ['pop', 'O(1)', 'Reads one slot and moves top'],
        ['peek', 'O(1)', 'Reads one slot'],
        ['isEmpty / isFull', 'O(1)', 'One comparison']]],
      ['p', 'Space is O(n) for n stored items. The array version reserves its whole capacity up front, so it uses O(capacity) space even when mostly empty.']] },
    { title: 'Advantages and Disadvantages', body: [
      ['table', [['Advantages', 'Disadvantages'],
        ['Every operation is O(1)', 'Only the top is reachable. Reading a middle item means popping items off'],
        ['Simple to build and to reason about', 'A fixed-size array stack can overflow'],
        ['Fits any problem that needs reverse order', 'No access by index and no fast search']]]] },
    { title: 'Comparison', body: [
      ['table', [['', 'Stack', 'Queue', 'Array', 'Linked list'],
        ['Order rule', 'LIFO', 'FIFO', 'Any index', 'Follow links from the head'],
        ['Add', 'Top, O(1)', 'Rear, O(1)', 'Middle needs shifting, O(n)', 'Head, O(1)'],
        ['Remove', 'Top, O(1)', 'Front, O(1)', 'Middle needs shifting, O(n)', 'Head, O(1)'],
        ['Choose it when', 'Newest first: undo, brackets, calls', 'Oldest first: waiting lines, scheduling', 'You need access by index', 'You insert and delete often']]]] },
    { title: 'C Code Examples', body: [
      ['p', 'A complete C11 program for an array-based stack, with a normal case, a boundary case (full), and an error case (empty). Copy it and run it on your computer with GCC; this website does not run C code. See the "Run C" page.'],
      ['code', 'stack_array.c'],
      ['p', 'Build and run: gcc -std=c11 -Wall -Wextra -pedantic -o stack_array stack_array.c && ./stack_array'],
      ['p', 'Expected output:'],
      ['code', 'stack_array.out']] },
    { title: 'Code Explanation', body: [
      ['ul', [
        'Stack: a struct with a fixed array data[4] and the integer top. Keeping both in one struct lets us pass the whole stack as one pointer.',
        'stack_init(s): sets top to -1, which means empty. Without it, top holds garbage.',
        'stack_is_empty / stack_is_full: compare top with -1 and with capacity - 1. Every other function calls them first.',
        'stack_push(s, value): refuses with STACK_FULL when full. Otherwise ++s->top moves top up first, then stores value at the new top.',
        'stack_pop(s, out): refuses with STACK_EMPTY when empty. Otherwise it copies data[top] into *out and moves top down. We return the value through the pointer out because the return value reports success or failure.',
        'stack_peek(s, out): same as pop but leaves top alone. The parameter is const Stack * because peek must not change the stack.']],
      ['p', 'Dry run of main (capacity 4):'],
      ['table', [['Step', 'Call', 'top', 'Items (bottom to top)', 'Result'],
        ['1', 'push 10', '0', '10', 'STACK_OK'],
        ['2', 'push 20', '1', '10 20', 'STACK_OK'],
        ['3', 'push 30', '2', '10 20 30', 'STACK_OK'],
        ['4', 'peek', '2', '10 20 30', 'prints 30'],
        ['5', 'pop', '1', '10 20', 'prints 30'],
        ['6', 'push 40', '2', '10 20 40', 'STACK_OK'],
        ['7', 'push 50', '3', '10 20 40 50', 'STACK_OK (now full)'],
        ['8', 'push 60', '3', '10 20 40 50', 'STACK_FULL, nothing changes'],
        ['9', 'pop x4', '-1', '(empty)', 'prints 50, 40, 20, 10'],
        ['10', 'pop', '-1', '(empty)', 'STACK_EMPTY']]]] },
    { title: 'Programming Exercises', body: [
      ['p', 'Each exercise has a description, hints, starter code with built-in tests, and a reference solution you can reveal after trying.'],
      ['exercises']] },
    { title: 'Knowledge Assessment', body: [['quiz']] }
  ]
};
