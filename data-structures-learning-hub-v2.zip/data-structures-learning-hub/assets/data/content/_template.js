// TEMPLATE for a new lesson. Copy to assets/data/content/<slug>.js and fill in.
// The lesson needs exactly 15 sections in this order:
//  1 Concept and Definition   2 Why It Exists          3 Real-life Analogy
//  4 How It Works Internally  5 Visual Illustration    6 Step-by-step Simulation
//  7 Main Operations          8 Real-world Applications 9 Complexity Analysis
// 10 Advantages and Disadvantages  11 Comparison        12 C Code Examples
// 13 Code Explanation        14 Programming Exercises  15 Knowledge Assessment
//
// Block types for section bodies:
//  ['p', 'text']  ['ul', ['item', ...]]  ['table', [[header...], [row...]]]
//  ['pre', 'monospace text, for memory diagrams']
//  ['diagram', items]  ['sim', operations]  ['play']   (need an entry in assets/js/lesson/sims.js)
//  ['code', 'file.c']  (file lives in assets/code/<slug>/ with a matching file.out)
//  ['exercises']  ['quiz']
import { quiz } from '../quizzes/SLUG-quiz.js';

export default {
  minutes: 45,
  related: [], // slugs from assets/data/lessons.js
  quiz,
  sections: [
    { title: 'Concept and Definition', body: [['p', '...']] }
    // ... 14 more sections
  ]
};
