// Exercises. Files: assets/exercises/<id>/starter.c and solution.c (built by tools/build-exercises.py).
export const exercises = [
  {
    id: 'stack-l1', lesson: 'stack', level: 1, title: 'Implement push and pop',
    objective: 'Practice the two core stack operations on an array-based stack.',
    concepts: ['array', 'structures-in-c'],
    description: 'Complete stack_push and stack_pop for a stack of capacity 5. Both return 0 on success and -1 on failure (full or empty).',
    io: 'No input. The program runs built-in tests and prints PASS or FAIL for each one.',
    examples: [['push 1, push 2, pop', 'pop returns 2'], ['pop on an empty stack', 'returns -1']],
    tests: ['Normal: push 1 and 2, then pop gives 2 then 1', 'Boundary: a 6th push into a capacity-5 stack returns -1', 'Error: pop on an empty stack returns -1'],
    hints: ['top is an index. -1 means the stack is empty.', 'Check for full or empty BEFORE touching data[].', 'push: move top up, then store. pop: read the item, then move top down.'],
    explanation: 'Each function first checks its failure case, so the array is never accessed out of bounds. push uses ++s->top so the item goes into the next free slot. pop uses s->top-- so it reads the current top and then moves it down.',
    complexity: 'Time O(1) per operation. Extra space O(1).'
  },
  {
    id: 'stack-l2', lesson: 'stack', level: 2, title: 'Check balanced brackets',
    objective: 'Combine push, pop, and isEmpty to solve a real problem.',
    concepts: ['stack', 'array'],
    description: 'Write is_balanced(s). It returns 1 when every opening bracket ( [ { is closed by the matching bracket in the correct order, otherwise 0. Ignore all other characters.',
    io: 'Input: a C string. Output: 1 or 0. The built-in tests call your function.',
    examples: [['([]{})', '1'], ['(]', '0']],
    tests: ['Normal: "([]{})" and "a(b)c" are balanced', 'Boundary: the empty string is balanced', 'Error cases: "(]", "((" and "]" are not balanced'],
    hints: ['Push every opening bracket.', 'On a closing bracket, pop and check that it is the matching opening bracket.', 'A closing bracket with an empty stack, or a non-empty stack at the end, means NOT balanced.'],
    explanation: 'The most recent unclosed bracket must be closed first, which is exactly LIFO. The stack holds the unclosed brackets. Three failures are possible: closing with nothing open, closing the wrong kind, or brackets left open at the end.',
    complexity: 'Time O(n) for a string of length n. Space O(n) in the worst case.'
  },
  {
    id: 'stack-l3', lesson: 'stack', level: 3, title: 'Evaluate a postfix expression',
    objective: 'Use a stack to evaluate expressions and handle every error case.',
    concepts: ['stack', 'array'],
    description: 'Write eval_postfix(expr, &result). The expression has single digits and the operators + - * / separated by spaces, for example "5 1 2 + 4 * + 3 -". Return 0 and set result, or return -1 on any error.',
    io: 'Input: a postfix string. Output: return code and result. The built-in tests call your function.',
    examples: [['2 3 +', '5'], ['5 1 2 + 4 * + 3 -', '14']],
    tests: ['Normal: "2 3 +" = 5, "5 1 2 + 4 * + 3 -" = 14, "8 2 /" = 4', 'Error: division by zero "4 0 /"', 'Error: too few operands "+", leftover values "1 2", bad character "2 x +"'],
    hints: ['A digit is pushed as a number: c - \'0\'.', 'For an operator, pop b FIRST, then a, and push (a op b). The order matters for - and /.', 'At the end exactly one value must remain on the stack.'],
    explanation: 'Postfix puts operators after their operands, so a stack removes the need for parentheses. When an operator appears, its two operands are the two newest values. We pop b then a because b was pushed last. The error checks cover underflow, division by zero, bad characters, and leftover values.',
    complexity: 'Time O(n) for n characters. Space O(n).'
  }
];
