// answer = index of the correct option (starts at 0)
export const quiz = [
  { question: 'You push A, then B, then C. Which item does pop() remove?',
    options: ['A', 'B', 'C'], answer: 2,
    explanation: 'A stack is LIFO, so the last item pushed (C) leaves first.' },
  { question: 'What does peek() do?',
    options: ['Removes the top item', 'Shows the top item without removing it', 'Adds a new item'], answer: 1,
    explanation: 'peek() only reads the top item. The stack does not change.' },
  { question: 'What happens if you pop() an empty stack?',
    options: ['Underflow: there is nothing to remove', 'It returns the first item pushed', 'The stack doubles in size'], answer: 0,
    explanation: 'An empty stack has no top item. A correct program must check isEmpty() first.' },
  { question: 'Start empty. push(1), push(2), pop(), push(3), pop(). What is on top now?',
    options: ['1', '2', '3', 'Nothing, the stack is empty'], answer: 0,
    explanation: 'After push 1, push 2: [1, 2]. pop removes 2: [1]. push 3: [1, 3]. pop removes 3: [1]. The top is 1.' },
  { question: 'In the array version, what does top == -1 mean?',
    options: ['The stack is full', 'The stack is empty', 'The array has one item'], answer: 1,
    explanation: 'top is the index of the newest item. No items means there is no valid index, so -1 is used.' },
  { question: 'Find the bug: stack_push does data[s->top++] = value; when top starts at -1. What goes wrong?',
    options: ['It writes to data[-1], outside the array', 'Nothing, it is correct', 'It pushes the value twice'], answer: 0,
    explanation: 'Post-increment uses the old value of top first. The write goes to data[-1], which is undefined behavior. Use ++s->top.' }
];
