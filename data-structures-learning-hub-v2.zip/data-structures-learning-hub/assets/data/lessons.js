// Single source of truth for the curriculum and lesson status.
// Line format: slug|track|level|type|prerequisites (comma separated)|status
// level: B, I, A. type: concept, ds, algo. status: done (default: planned).
const TABLE = `
what-is-a-data-structure|Foundations|B|concept
abstract-data-types|Foundations|B|concept|what-is-a-data-structure
linear-vs-non-linear|Foundations|B|concept|what-is-a-data-structure
static-vs-dynamic-memory|Foundations|B|concept|what-is-a-data-structure
pointers-in-c|Foundations|B|concept|static-vs-dynamic-memory
structures-in-c|Foundations|B|concept|pointers-in-c
time-complexity|Foundations|B|concept|what-is-a-data-structure
space-complexity|Foundations|B|concept|time-complexity
big-o-omega-theta|Foundations|I|concept|time-complexity,space-complexity
c-refresher|Foundations|B|concept
recursion|Foundations|B|concept|c-refresher
array|Linear|B|ds|time-complexity,c-refresher
dynamic-array|Linear|B|ds|array,pointers-in-c
singly-linked-list|Linear|B|ds|pointers-in-c,structures-in-c
doubly-linked-list|Linear|I|ds|singly-linked-list
circular-linked-list|Linear|I|ds|singly-linked-list
stack|Linear|B|ds|array|done
queue|Linear|B|ds|array,singly-linked-list
circular-queue|Linear|I|ds|queue
deque|Linear|I|ds|doubly-linked-list,circular-queue
priority-queue|Linear|I|ds|queue
hash-functions|Hash|I|ds|array
hash-table|Hash|I|ds|hash-functions
collision-resolution|Hash|I|ds|hash-table,singly-linked-list
hash-map|Hash|I|ds|hash-table
hash-set|Hash|I|ds|hash-table
general-tree|Trees|I|ds|singly-linked-list,recursion
binary-tree|Trees|I|ds|general-tree
binary-search-tree|Trees|I|ds|binary-tree
heap|Trees|I|ds|binary-tree,array
avl-tree|Trees|A|ds|binary-search-tree
red-black-tree|Trees|A|ds|avl-tree
trie|Trees|I|ds|general-tree,array
b-tree|Trees|A|ds|binary-search-tree
b-plus-tree|Trees|A|ds|b-tree
graph-basics|Graphs|I|ds|general-tree
adjacency-matrix|Graphs|I|ds|graph-basics,array
adjacency-list|Graphs|I|ds|graph-basics,singly-linked-list
undirected-graph|Graphs|I|ds|graph-basics
directed-graph|Graphs|I|ds|graph-basics
weighted-graph|Graphs|I|ds|undirected-graph
disjoint-set-union|Advanced|A|ds|array,general-tree
fenwick-tree|Advanced|A|ds|array,big-o-omega-theta
segment-tree|Advanced|A|ds|binary-tree,array
linear-search|Algorithms|B|algo|array
binary-search|Algorithms|B|algo|array
elementary-sorts|Algorithms|B|algo|array
merge-sort|Algorithms|I|algo|recursion
quick-sort|Algorithms|I|algo|recursion
heap-sort|Algorithms|I|algo|heap
tree-traversals|Algorithms|I|algo|binary-tree,queue
bfs|Algorithms|I|algo|adjacency-list,queue
dfs|Algorithms|I|algo|adjacency-list,stack
dijkstra|Algorithms|A|algo|weighted-graph,heap
topological-sort|Algorithms|A|algo|directed-graph,dfs
kruskal-mst|Algorithms|A|algo|disjoint-set-union,weighted-graph
`;

const WORDS = { bfs: 'BFS', dfs: 'DFS', avl: 'AVL', c: 'C' };
const SMALL = new Set(['in', 'vs', 'a', 'is', 'of', 'and']);
const TITLES = {
  'linear-vs-non-linear': 'Linear vs Non-linear Structures',
  'big-o-omega-theta': 'Big O, Big Omega and Big Theta',
  'b-tree': 'B-Tree', 'b-plus-tree': 'B+ Tree', 'red-black-tree': 'Red-Black Tree',
  'elementary-sorts': 'Bubble, Selection and Insertion Sort',
  dijkstra: "Dijkstra's Algorithm", 'kruskal-mst': "Kruskal's MST"
};
const titleOf = slug => TITLES[slug] || slug.split('-')
  .map((w, i) => WORDS[w] || (i && SMALL.has(w) ? w : w[0].toUpperCase() + w.slice(1))).join(' ');

export const lessons = TABLE.trim().split('\n').map(line => {
  const [slug, track, level, type, pre, status] = line.split('|');
  return { slug, track, level, type, title: titleOf(slug), prerequisites: pre ? pre.split(',') : [], status: status || 'planned' };
});
