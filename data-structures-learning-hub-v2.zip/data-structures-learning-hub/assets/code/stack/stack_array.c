/*
 * stack_array.c - Array-based stack of int (C11)
 * Build: gcc -std=c11 -Wall -Wextra -pedantic -o stack_array stack_array.c
 * Run:   ./stack_array
 */
#include <stdbool.h>
#include <stdio.h>

#define STACK_CAPACITY 4

typedef struct {
    int data[STACK_CAPACITY];
    int top; /* index of the top item, -1 when empty */
} Stack;

typedef enum { STACK_OK, STACK_FULL, STACK_EMPTY } StackStatus;

void stack_init(Stack *s) { s->top = -1; }
bool stack_is_empty(const Stack *s) { return s->top == -1; }
bool stack_is_full(const Stack *s) { return s->top == STACK_CAPACITY - 1; }

StackStatus stack_push(Stack *s, int value) {
    if (stack_is_full(s)) return STACK_FULL;
    s->data[++s->top] = value;
    return STACK_OK;
}

StackStatus stack_pop(Stack *s, int *out) {
    if (stack_is_empty(s)) return STACK_EMPTY;
    *out = s->data[s->top--];
    return STACK_OK;
}

StackStatus stack_peek(const Stack *s, int *out) {
    if (stack_is_empty(s)) return STACK_EMPTY;
    *out = s->data[s->top];
    return STACK_OK;
}

int main(void) {
    Stack s;
    int v;
    stack_init(&s);

    /* normal case */
    stack_push(&s, 10); stack_push(&s, 20); stack_push(&s, 30);
    stack_peek(&s, &v); printf("peek -> %d\n", v);
    stack_pop(&s, &v);  printf("pop  -> %d\n", v);

    /* boundary case: fill to capacity, then overflow */
    stack_push(&s, 40); stack_push(&s, 50);
    printf("push on full stack -> %s\n",
           stack_push(&s, 60) == STACK_FULL ? "STACK_FULL" : "unexpected");

    /* drain, then error case: underflow */
    while (stack_pop(&s, &v) == STACK_OK) printf("pop  -> %d\n", v);
    printf("pop on empty stack -> %s\n",
           stack_pop(&s, &v) == STACK_EMPTY ? "STACK_EMPTY" : "unexpected");
    return 0;
}
